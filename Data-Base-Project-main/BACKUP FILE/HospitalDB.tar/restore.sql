--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4
-- Dumped by pg_dump version 16.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Hospital";
--
-- Name: Hospital; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Hospital" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_American Samoa.1256';


ALTER DATABASE "Hospital" OWNER TO postgres;

\connect "Hospital"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accountant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accountant (
    accountantid integer NOT NULL,
    phone character varying(11) NOT NULL,
    salary numeric(8,2) NOT NULL,
    sex character(1) NOT NULL,
    street character varying(20),
    city character varying(20),
    shift character varying(10) NOT NULL,
    age integer NOT NULL,
    accountantname character varying(50) NOT NULL,
    apartment_block_no integer
);


ALTER TABLE public.accountant OWNER TO postgres;

--
-- Name: accountant_accountantid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accountant_accountantid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accountant_accountantid_seq OWNER TO postgres;

--
-- Name: accountant_accountantid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accountant_accountantid_seq OWNED BY public.accountant.accountantid;


--
-- Name: bill; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bill (
    billid integer NOT NULL,
    patid integer NOT NULL,
    accid integer NOT NULL,
    totalbill numeric(10,2) NOT NULL,
    hasinsurance boolean
);


ALTER TABLE public.bill OWNER TO postgres;

--
-- Name: bill_billid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bill_billid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bill_billid_seq OWNER TO postgres;

--
-- Name: bill_billid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bill_billid_seq OWNED BY public.bill.billid;


--
-- Name: depatment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.depatment (
    departmentid integer NOT NULL,
    departmentname character varying(50) NOT NULL,
    departmentlocation character varying(50) NOT NULL
);


ALTER TABLE public.depatment OWNER TO postgres;

--
-- Name: depatment_departmentid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.depatment_departmentid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.depatment_departmentid_seq OWNER TO postgres;

--
-- Name: depatment_departmentid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.depatment_departmentid_seq OWNED BY public.depatment.departmentid;


--
-- Name: doctor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctor (
    doctorid integer NOT NULL,
    doctorname character varying(20) NOT NULL,
    depid integer NOT NULL,
    salary numeric(8,2) NOT NULL,
    sex character(1) NOT NULL,
    apartmentblockno integer,
    street character varying(20),
    city character varying(20),
    age integer NOT NULL,
    shift character varying(10) NOT NULL,
    medical_specialization character varying(50) NOT NULL,
    phone character varying(12)[]
);


ALTER TABLE public.doctor OWNER TO postgres;

--
-- Name: doctor_doctorid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.doctor_doctorid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_doctorid_seq OWNER TO postgres;

--
-- Name: doctor_doctorid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.doctor_doctorid_seq OWNED BY public.doctor.doctorid;


--
-- Name: doctorwritetestreport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctorwritetestreport (
    docid integer NOT NULL,
    patid integer NOT NULL,
    diagnosis character varying(100) NOT NULL,
    "reportDate" date
);


ALTER TABLE public.doctorwritetestreport OWNER TO postgres;

--
-- Name: medicalrecord; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medicalrecord (
    recordid integer NOT NULL,
    recorddate date NOT NULL,
    patid integer NOT NULL,
    diagnosis character varying(100)
);


ALTER TABLE public.medicalrecord OWNER TO postgres;

--
-- Name: medicalrecord_recordid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.medicalrecord_recordid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medicalrecord_recordid_seq OWNER TO postgres;

--
-- Name: medicalrecord_recordid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.medicalrecord_recordid_seq OWNED BY public.medicalrecord.recordid;


--
-- Name: nurse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nurse (
    nurseid integer NOT NULL,
    nursename character varying(20) NOT NULL,
    wardid integer NOT NULL,
    salary numeric(8,2) NOT NULL,
    sex character(1) NOT NULL,
    apartmentblockno integer,
    street character varying(20),
    city character varying(20),
    age integer NOT NULL,
    shift character varying(10) NOT NULL,
    supervisor_id integer,
    phone character varying(13)[]
);


ALTER TABLE public.nurse OWNER TO postgres;

--
-- Name: nurse_nurseid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nurse_nurseid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nurse_nurseid_seq OWNER TO postgres;

--
-- Name: nurse_nurseid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nurse_nurseid_seq OWNED BY public.nurse.nurseid;


--
-- Name: patient; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient (
    patientid integer NOT NULL,
    patientname character varying(20) NOT NULL,
    age numeric(5,0) NOT NULL,
    phone character varying(11),
    sex character(1) NOT NULL,
    apartmentblockno integer,
    street character varying(20),
    city character varying(20),
    wardid integer NOT NULL,
    enterdate date,
    exitdate date
);


ALTER TABLE public.patient OWNER TO postgres;

--
-- Name: patient_patientid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.patient_patientid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_patientid_seq OWNER TO postgres;

--
-- Name: patient_patientid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.patient_patientid_seq OWNED BY public.patient.patientid;


--
-- Name: patient_wardid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.patient_wardid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_wardid_seq OWNER TO postgres;

--
-- Name: patient_wardid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.patient_wardid_seq OWNED BY public.patient.wardid;


--
-- Name: recordtreatment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recordtreatment (
    recid integer NOT NULL,
    treatment character varying(50) NOT NULL
);


ALTER TABLE public.recordtreatment OWNER TO postgres;

--
-- Name: testreporttreatments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.testreporttreatments (
    docid integer NOT NULL,
    patid integer NOT NULL,
    treatments character varying(50) NOT NULL
);


ALTER TABLE public.testreporttreatments OWNER TO postgres;

--
-- Name: ward; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ward (
    wardid integer NOT NULL,
    capacity integer NOT NULL,
    availability integer NOT NULL,
    depatmentno integer NOT NULL
);


ALTER TABLE public.ward OWNER TO postgres;

--
-- Name: ward_wardid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ward_wardid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ward_wardid_seq OWNER TO postgres;

--
-- Name: ward_wardid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ward_wardid_seq OWNED BY public.ward.wardid;


--
-- Name: accountant accountantid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accountant ALTER COLUMN accountantid SET DEFAULT nextval('public.accountant_accountantid_seq'::regclass);


--
-- Name: bill billid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill ALTER COLUMN billid SET DEFAULT nextval('public.bill_billid_seq'::regclass);


--
-- Name: depatment departmentid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depatment ALTER COLUMN departmentid SET DEFAULT nextval('public.depatment_departmentid_seq'::regclass);


--
-- Name: doctor doctorid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor ALTER COLUMN doctorid SET DEFAULT nextval('public.doctor_doctorid_seq'::regclass);


--
-- Name: medicalrecord recordid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicalrecord ALTER COLUMN recordid SET DEFAULT nextval('public.medicalrecord_recordid_seq'::regclass);


--
-- Name: nurse nurseid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nurse ALTER COLUMN nurseid SET DEFAULT nextval('public.nurse_nurseid_seq'::regclass);


--
-- Name: patient patientid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient ALTER COLUMN patientid SET DEFAULT nextval('public.patient_patientid_seq'::regclass);


--
-- Name: patient wardid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient ALTER COLUMN wardid SET DEFAULT nextval('public.patient_wardid_seq'::regclass);


--
-- Name: ward wardid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ward ALTER COLUMN wardid SET DEFAULT nextval('public.ward_wardid_seq'::regclass);


--
-- Data for Name: accountant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accountant (accountantid, phone, salary, sex, street, city, shift, age, accountantname, apartment_block_no) FROM stdin;
\.
COPY public.accountant (accountantid, phone, salary, sex, street, city, shift, age, accountantname, apartment_block_no) FROM '$$PATH$$/4878.dat';

--
-- Data for Name: bill; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bill (billid, patid, accid, totalbill, hasinsurance) FROM stdin;
\.
COPY public.bill (billid, patid, accid, totalbill, hasinsurance) FROM '$$PATH$$/4880.dat';

--
-- Data for Name: depatment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.depatment (departmentid, departmentname, departmentlocation) FROM stdin;
\.
COPY public.depatment (departmentid, departmentname, departmentlocation) FROM '$$PATH$$/4867.dat';

--
-- Data for Name: doctor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctor (doctorid, doctorname, depid, salary, sex, apartmentblockno, street, city, age, shift, medical_specialization, phone) FROM stdin;
\.
COPY public.doctor (doctorid, doctorname, depid, salary, sex, apartmentblockno, street, city, age, shift, medical_specialization, phone) FROM '$$PATH$$/4874.dat';

--
-- Data for Name: doctorwritetestreport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctorwritetestreport (docid, patid, diagnosis, "reportDate") FROM stdin;
\.
COPY public.doctorwritetestreport (docid, patid, diagnosis, "reportDate") FROM '$$PATH$$/4875.dat';

--
-- Data for Name: medicalrecord; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medicalrecord (recordid, recorddate, patid, diagnosis) FROM stdin;
\.
COPY public.medicalrecord (recordid, recorddate, patid, diagnosis) FROM '$$PATH$$/4882.dat';

--
-- Data for Name: nurse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nurse (nurseid, nursename, wardid, salary, sex, apartmentblockno, street, city, age, shift, supervisor_id, phone) FROM stdin;
\.
COPY public.nurse (nurseid, nursename, wardid, salary, sex, apartmentblockno, street, city, age, shift, supervisor_id, phone) FROM '$$PATH$$/4885.dat';

--
-- Data for Name: patient; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient (patientid, patientname, age, phone, sex, apartmentblockno, street, city, wardid, enterdate, exitdate) FROM stdin;
\.
COPY public.patient (patientid, patientname, age, phone, sex, apartmentblockno, street, city, wardid, enterdate, exitdate) FROM '$$PATH$$/4872.dat';

--
-- Data for Name: recordtreatment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recordtreatment (recid, treatment) FROM stdin;
\.
COPY public.recordtreatment (recid, treatment) FROM '$$PATH$$/4883.dat';

--
-- Data for Name: testreporttreatments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.testreporttreatments (docid, patid, treatments) FROM stdin;
\.
COPY public.testreporttreatments (docid, patid, treatments) FROM '$$PATH$$/4876.dat';

--
-- Data for Name: ward; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ward (wardid, capacity, availability, depatmentno) FROM stdin;
\.
COPY public.ward (wardid, capacity, availability, depatmentno) FROM '$$PATH$$/4869.dat';

--
-- Name: accountant_accountantid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accountant_accountantid_seq', 1, false);


--
-- Name: bill_billid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bill_billid_seq', 1, false);


--
-- Name: depatment_departmentid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.depatment_departmentid_seq', 1, false);


--
-- Name: doctor_doctorid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.doctor_doctorid_seq', 1, false);


--
-- Name: medicalrecord_recordid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.medicalrecord_recordid_seq', 1, false);


--
-- Name: nurse_nurseid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nurse_nurseid_seq', 1, false);


--
-- Name: patient_patientid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.patient_patientid_seq', 1, false);


--
-- Name: patient_wardid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.patient_wardid_seq', 1, false);


--
-- Name: ward_wardid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ward_wardid_seq', 1, false);


--
-- Name: accountant accountant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accountant
    ADD CONSTRAINT accountant_pkey PRIMARY KEY (accountantid);


--
-- Name: bill bill_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill
    ADD CONSTRAINT bill_pkey PRIMARY KEY (billid);


--
-- Name: depatment depatment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depatment
    ADD CONSTRAINT depatment_pkey PRIMARY KEY (departmentid);


--
-- Name: doctor doctor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor
    ADD CONSTRAINT doctor_pkey PRIMARY KEY (doctorid);


--
-- Name: doctorwritetestreport doctorwritetestreport_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctorwritetestreport
    ADD CONSTRAINT doctorwritetestreport_pkey PRIMARY KEY (docid, patid);


--
-- Name: medicalrecord medicalrecord_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicalrecord
    ADD CONSTRAINT medicalrecord_pkey PRIMARY KEY (recordid);


--
-- Name: nurse nurse_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nurse
    ADD CONSTRAINT nurse_pkey PRIMARY KEY (nurseid);


--
-- Name: patient patient_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT patient_pkey PRIMARY KEY (patientid);


--
-- Name: testreporttreatments testreporttreatments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.testreporttreatments
    ADD CONSTRAINT testreporttreatments_pkey PRIMARY KEY (docid, patid);


--
-- Name: ward ward_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ward
    ADD CONSTRAINT ward_pkey PRIMARY KEY (wardid);


--
-- Name: bill fk_bill_accountant; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill
    ADD CONSTRAINT fk_bill_accountant FOREIGN KEY (accid) REFERENCES public.accountant(accountantid);


--
-- Name: bill fk_bill_patient; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill
    ADD CONSTRAINT fk_bill_patient FOREIGN KEY (patid) REFERENCES public.patient(patientid);


--
-- Name: doctor fk_doctor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor
    ADD CONSTRAINT fk_doctor FOREIGN KEY (depid) REFERENCES public.depatment(departmentid);


--
-- Name: testreporttreatments fk_doctor__test; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.testreporttreatments
    ADD CONSTRAINT fk_doctor__test FOREIGN KEY (docid, patid) REFERENCES public.doctorwritetestreport(docid, patid);


--
-- Name: doctorwritetestreport fk_doctor_test; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctorwritetestreport
    ADD CONSTRAINT fk_doctor_test FOREIGN KEY (docid) REFERENCES public.doctor(doctorid);


--
-- Name: patient fk_patient; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT fk_patient FOREIGN KEY (wardid) REFERENCES public.ward(wardid);


--
-- Name: doctorwritetestreport fk_patient_test; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctorwritetestreport
    ADD CONSTRAINT fk_patient_test FOREIGN KEY (patid) REFERENCES public.patient(patientid);


--
-- Name: medicalrecord fk_record; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicalrecord
    ADD CONSTRAINT fk_record FOREIGN KEY (patid) REFERENCES public.patient(patientid);


--
-- Name: nurse fk_supervisor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nurse
    ADD CONSTRAINT fk_supervisor FOREIGN KEY (supervisor_id) REFERENCES public.nurse(nurseid);


--
-- Name: recordtreatment fk_treatment; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recordtreatment
    ADD CONSTRAINT fk_treatment FOREIGN KEY (recid) REFERENCES public.medicalrecord(recordid);


--
-- Name: ward fk_ward; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ward
    ADD CONSTRAINT fk_ward FOREIGN KEY (depatmentno) REFERENCES public.depatment(departmentid);


--
-- Name: nurse fk_ward; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nurse
    ADD CONSTRAINT fk_ward FOREIGN KEY (wardid) REFERENCES public.ward(wardid);


--
-- PostgreSQL database dump complete
--

